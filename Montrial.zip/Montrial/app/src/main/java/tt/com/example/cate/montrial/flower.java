package tt.com.example.cate.montrial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class flower extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flower);
    }
    public void onClick(View v) {
        Intent intent = new Intent();

        switch(v.getId()) {
            case R.id.ros:
                intent = new Intent(this, Rose.class);
                break;
            case R.id.stat:
                intent = new Intent(this, Statice.class);
                break;
            case R.id.sun:
                intent = new Intent(this, Sunflower.class);
                break;

            case R.id.car:
                intent = new Intent(this, Carnation.class);
                break;
            case R.id.lil:
                intent = new Intent(this, Lily.class);
                break;
        }

        startActivity(intent);
    }
}
