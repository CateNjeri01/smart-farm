package tt.com.example.cate.montrial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class page1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page1);

    }
    public void onClick(View v) {
        Intent intent = new Intent();

        switch(v.getId()) {
            case R.id.crp:
                intent = new Intent(this, crop.class);
                break;
            case R.id.wea:
                intent = new Intent(this, weather.class);
                break;
            case R.id.exp:
                intent = new Intent(this, expert.class);
                break;
            case R.id.area:
                intent = new Intent(this, discuss.class);
                break;
            case R.id.mrk:
                intent = new Intent();
        }

        startActivity(intent);
    }


    }

