package tt.com.example.cate.montrial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class vegetable extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vegetable);
    }
    public void onClick(View v) {
        Intent intent = new Intent();

        switch(v.getId()) {

            case R.id.mush:
                intent = new Intent(this, Mushroom.class);
                break;
            case R.id.let:
                intent = new Intent(this, Lettuce.class);
                break;

            case R.id.cila:
                intent = new Intent(this, Cilantro.class);
                break;
            case R.id.cab:
                intent = new Intent(this, Cabbage.class);
                break;
        }

        startActivity(intent);
    }
}
