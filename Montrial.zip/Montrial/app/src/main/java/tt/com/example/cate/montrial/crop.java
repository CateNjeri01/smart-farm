package tt.com.example.cate.montrial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class crop extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop);}

        public void onClick(View v) {
            Intent intent = new Intent();

            switch(v.getId()) {
                case R.id.fruits:
                    intent = new Intent(this, fruit.class);
                    break;
                case R.id.veg:
                    intent = new Intent(this, vegetable.class);
                    break;

                case R.id.flo:
                    intent = new Intent(this, flower.class);
                    break;

            }

            startActivity(intent);
        }
    }

