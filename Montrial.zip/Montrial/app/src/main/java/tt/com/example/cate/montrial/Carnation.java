package tt.com.example.cate.montrial;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Carnation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carnation);
    }
}
