package tt.com.example.cate.montrial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
private EditText uname;
private EditText password;
private Button login;
private Button forgot;
private Button create;
private Button exi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
uname=(EditText)findViewById(R.id.name);
password=(EditText)findViewById(R.id.pwd);
login=(Button)findViewById(R.id.log);
forgot=(Button)findViewById(R.id.fpwd);
create=(Button)findViewById(R.id.acc);
exi=(Button)findViewById(R.id.exit);
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,account.class);
                startActivity(intent);

            }
        });

login.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if(validate(uname.getText().toString(), password.getText().toString())){
            Toast("Login Success");
            Intent intent=new Intent(MainActivity.this,page1.class);
            startActivity(intent);
        }else{
            Toast("Login Failed");
        }
    }

});
    }
    private  boolean validate(String uname, String password){
        if(uname.equals("cate") && password.equals("1234")){
            return true;
        }else{
            return false;
        }
    }
    private void Toast(String toast){
        Toast.makeText(getApplicationContext(), toast, Toast.LENGTH_SHORT).show();
    }

    }

